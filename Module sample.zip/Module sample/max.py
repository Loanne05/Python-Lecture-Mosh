#Module
def find_max(numbers): #10,3,6,2
    maximum = numbers[0]
    for number in numbers:
        if number > maximum:
            maximum = number
        return maximum







"""
numbers = [10,3,6,2]
def find_max(numbers):
    maximum = numbers[0]
    for number in numbers:
        if number > maximum:
            maximum = number
        return maximum
print(maximum)


def find_max():
    max = 0
    for number in numbers:
        if number > max:
            max = number
            return max
"""





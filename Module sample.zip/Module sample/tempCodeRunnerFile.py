#module

from max import find_max

numbers = [10,3,6,2]
maximum = find_max(numbers)
print(maximum)

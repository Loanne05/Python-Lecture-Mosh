import converters
from converters import kg_to_lbs #specific

kg_to_lbs(100)


print(converters.kg_to_lbs(70))